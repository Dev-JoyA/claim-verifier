import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SKIPPED_FOLDERS = new Set(["node_modules", ".git", "results", "sources", "gold"]);
const KEPT_BY_TOOLS = new Set([
  ".gitignore",
  ".env",
  ".env.example",
  ".prettierrc",
  ".prettierignore",
  "package.json",
  "package-lock.json",
  "README.md",
  "LICENSE",
]);
const CODE = new Set([".js", ".html", ".css"]);
const LEFTOVER = /\.(zip|gz|tgz|log|tmp|bak)$|^tree\.txt$/i;
const REFERENCE_PATTERNS = [
  /from\s+["'](\.[^"']+)["']/g,
  /import\(\s*["'](\.[^"']+)["']\s*\)/g,
  /(?:src|href)=["']([^"':]+)["']/g,
];

function walk(folder, prefix = "") {
  const found = [];
  for (const entry of fs.readdirSync(path.join(ROOT, folder), { withFileTypes: true })) {
    if (entry.isDirectory() && SKIPPED_FOLDERS.has(entry.name)) continue;
    const relative = path.posix.join(prefix, entry.name);
    if (entry.isDirectory()) found.push(...walk(path.join(folder, entry.name), relative));
    else found.push(relative);
  }
  return found;
}

const files = walk(".");
const readText = (file) => fs.readFileSync(path.join(ROOT, file), "utf8");

function entryPoints() {
  const entries = new Set();
  const scripts = JSON.parse(readText("package.json")).scripts ?? {};

  for (const command of Object.values(scripts)) {
    for (const token of command.split(/\s+/)) {
      if (token.endsWith(".js") && files.includes(token)) entries.add(token);
    }
    if (/--test\b/.test(command)) {
      files.filter((file) => file.startsWith("test/") && file.endsWith(".js")).forEach((f) => entries.add(f));
    }
  }
  if (files.includes("public/index.html")) entries.add("public/index.html");
  return [...entries];
}

function referencesOf(file) {
  const text = readText(file);
  const found = new Set();
  for (const pattern of REFERENCE_PATTERNS) {
    for (const match of text.matchAll(pattern)) {
      const target = path.posix.normalize(path.posix.join(path.posix.dirname(file), match[1]));
      if (files.includes(target)) found.add(target);
    }
  }
  return found;
}

function reachableFrom(entries) {
  const reached = new Set(entries);
  const queue = [...entries];
  while (queue.length > 0) {
    const file = queue.pop();
    if (!CODE.has(path.posix.extname(file))) continue;
    for (const target of referencesOf(file)) {
      if (!reached.has(target)) {
        reached.add(target);
        queue.push(target);
      }
    }
  }
  return reached;
}

function neverMentioned(file, allText) {
  const name = path.posix.basename(file);
  return !allText.some(({ file: other, text }) => other !== file && text.includes(name));
}

function main() {
  const reached = reachableFrom(entryPoints());
  const textFiles = files.filter((file) => !LEFTOVER.test(path.posix.basename(file)));
  const allText = textFiles.map((file) => ({ file, text: readText(file) }));

  const leftovers = files.filter((file) => LEFTOVER.test(path.posix.basename(file)));
  const unreachedCode = files.filter(
    (file) => CODE.has(path.posix.extname(file)) && !reached.has(file) && !LEFTOVER.test(file)
  );
  const unmentioned = textFiles.filter(
    (file) =>
      !CODE.has(path.posix.extname(file)) &&
      !KEPT_BY_TOOLS.has(path.posix.basename(file)) &&
      neverMentioned(file, allText)
  );

  const show = (title, list, advice) => {
    console.log(`\n${title}`);
    console.log(list.length ? list.map((file) => `  ${file}`).join("\n") : "  none");
    if (list.length) console.log(`  -> ${advice}`);
  };

  console.log(`Checked ${files.length} files (skipping node_modules, results, sources and gold).`);
  show("Leftover archives or logs", leftovers, "usually safe to delete");
  show("Code that no script, test or page reaches", unreachedCode, "probably safe to delete, check first");
  show("Data files whose name appears nowhere else", unmentioned, "nothing reads them, probably safe to delete");
}

main();
